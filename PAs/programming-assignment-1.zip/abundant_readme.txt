CSCI 103 Abundant Commas Programming Assignment 

Name:

Email Address: 

NOTE: You can delete the questions, we only need your responses.

NOTE: It is helpful if you write at most 80 characters per line,
and avoid including special characters, so we can read your responses.

Please summarize the help you found useful for this assignment, which
may include office hours, discussion with peers, tutors, et cetera.
Saying "a CP on Tuesday" is ok if you don't remember their name.
If none, say "none".

:

================================ Questions ==================================

1. Which kind of a loop did you use to iterate through the input numbers? 
   Why?
   


2. Which kind of a loop did you use to find the proper divisors for a
   single input number? Why?

   
3. Review the programming idioms linked on the website.  Identify 3 idioms
   you either used or could have used in this program and briefly explain
   where an how they were/could be used.



================================ Remarks ====================================

Filling in anything here is OPTIONAL.

Approximately how long did you spend on this assignment?

:

Were there any specific problems you encountered? This is especially useful to
know if you turned it in incomplete.

:

Do you have any other remarks?

:
