#pragma once

#include "Shape.h"
#include <fstream>

//Add the required code here

