#pragma once

#include <fstream>

class Shape
{
public:
	virtual double calculateArea() = 0;
};

