#include <iostream>
#include <fstream>
#include <sstream>
#include "Rectangle.h"
#include "Logger.h"

Rectangle::Rectangle(std::ifstream& stream)
{
    //Initialize the rectangle
}

//Add the required code here
