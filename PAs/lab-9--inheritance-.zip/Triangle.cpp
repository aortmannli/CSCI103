#include <sstream>
#include "Triangle.h"
#include "Logger.h"

//Add the required code here
