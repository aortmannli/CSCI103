#pragma once

#include <fstream>
#include "Shape.h"

//Add the required code here

