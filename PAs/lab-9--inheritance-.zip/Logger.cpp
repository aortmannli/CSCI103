#include "Logger.h"
#include <iomanip>
#include <ctime>
#include <sstream>
#include <iostream>

std::ofstream Logger::_logStream;

const std::string Logger::ITEM_ERROR = "ERR 004 - Error while crearing a takeoff item.";
const std::string Logger::RECTANGLE_ERROR = "ERR 001 - Error while crearing a rectangle.";
const std::string Logger::TRIANLE_ERROR = "ERR 002 - Error while crearing a triangle.";
const std::string Logger::CIRCLE_ERROR = "ERR 003 - Error while crearing a circle.";

void Logger::open(std::string fileName)
{
	//Create a log file
}

void Logger::log(LogType logType, const std::string info)
{
	//Get the current date and time in the form of "%d-%m-%Y %H-%M-%S

	//use the log type add a relevant line to the log file. In the for of: 
	//	[time-date]: Info/Error: [info]
}

void Logger::close()
{
    //Close the log gile
}
