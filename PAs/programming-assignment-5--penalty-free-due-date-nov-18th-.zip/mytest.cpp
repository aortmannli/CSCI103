#include "bigint.h"
#include <iostream>
#include <fstream>
using namespace std;

int main() {
  BigInt a(-1);
  cout << a.to_string() << endl;
}