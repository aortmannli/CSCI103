#include <iostream>

int main() {
  int x;
  return x;
}