#!/bin/bash
sudo apt-get -y update
sudo apt-get -y install libpng-dev
